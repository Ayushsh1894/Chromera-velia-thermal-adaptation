CLIMATE DATA — Supplementary dataset for
Sharma et al., "Transcriptomic and lipidomic profiles reveal greater thermal
stability in a tropical versus a temperate isolate of Chromera velia"
==============================================================================

This folder contains the raw and processed sea water temperature datasets
underlying Figure 1B–C of the manuscript.

------------------------------------------------------------------------------
FILE INVENTORY
------------------------------------------------------------------------------

01_raw_SOOP-SST_GBR.csv          Raw IMOS SOOP-SST download for GBR region
02_raw_SOOP-SST_Sydney.csv       Raw IMOS SOOP-SST download for Sydney region
03_cleaned_SOOP-SST_GBR.csv      QC-filtered, spatially bounded GBR records
04_cleaned_SOOP-SST_Sydney.csv   QC-filtered, spatially bounded Sydney records
05_climatology_GBR.csv           Monthly climatology, GBR (used for Fig. 1C-A)
06_climatology_Sydney.csv        Monthly climatology, Sydney (used for Fig. 1C-A)
07_annual_means_GBR.csv          Annual mean temperature, GBR (used for Fig. 1C-B)
08_annual_means_Sydney.csv       Annual mean temperature, Sydney (used for Fig. 1C-B)

------------------------------------------------------------------------------
DATA SOURCE
------------------------------------------------------------------------------

Provider:   Integrated Marine Observing System (IMOS), Australia
Programme:  Ships of Opportunity Sea Surface Temperature Sub-Facility (SOOP-SST)
            Near real-time trajectory data
Portal:     Australian Ocean Data Network (AODN)
            https://portal.aodn.org.au
Downloaded: 2025 (files 01 and 02 as originally exported from the AODN portal)

Citation (please cite when reusing this data):

  Integrated Marine Observing System (IMOS). IMOS Ships of Opportunity Sea
  Surface Temperature Sub-Facility — near real-time data.
  Australian Ocean Data Network (AODN).
  https://portal.aodn.org.au

IMOS is a national collaborative research infrastructure supported by the
Australian Government, operated by a consortium of institutions as an
unincorporated joint venture, with the University of Tasmania as Lead Agent.

Note on the "SST" label: despite being named "Sea Surface Temperature", SOOP-SST
measurements are taken from ships' engine cooling-water intakes at
approximately 5–10 m depth. They represent near-surface sea water temperature,
not the ocean skin temperature retrieved from satellite radiometers.

------------------------------------------------------------------------------
GEOGRAPHIC BOUNDING BOXES
------------------------------------------------------------------------------

Great Barrier Reef region (OTI isolation site):
  Latitude:  10°S – 24°S
  Longitude: 142°E – 154°E

Sydney coastal region (SH isolation site):
  Latitude:  33.5°S – 34.0°S
  Longitude: 151.2°E – 152.3°E

------------------------------------------------------------------------------
PROCESSING PIPELINE (raw -> cleaned -> derived)
------------------------------------------------------------------------------

Cleaning (files 03, 04):
  1. Read raw CSV, skipping the file's header/metadata block.
  2. Retain only fields TIME, LATITUDE, LONGITUDE, TEMP, TEMP_quality_control,
     platform_code, vessel_name.
  3. Drop records missing TIME, TEMP, LATITUDE or LONGITUDE.
  4. Coerce TEMP to numeric; drop non-numeric.
  5. Retain only records with TEMP_quality_control == 'Z'
     (passed all IMOS QC tests).
  6. Restrict records to the regional bounding box above.
  7. Apply sanity bound: 10 °C ≤ TEMP ≤ 35 °C.
  8. Parse TIME to UTC datetime; add derived columns year and month.

Monthly climatology (files 05, 06):
  1. For each year and calendar month, compute the mean of all cleaned records.
  2. For each calendar month, average the per-year monthly means across years
     ("mean of yearly monthly means") to give the climatological monthly value.
  3. Standard deviation across years is reported alongside each monthly value.
  This approach avoids seasonal sampling bias caused by uneven ship visits.

Annual means (files 07, 08):
  1. For each calendar year, take the mean of all cleaned records in that year.
  2. Standard deviation and observation count reported alongside.

------------------------------------------------------------------------------
DATA COVERAGE
------------------------------------------------------------------------------

GBR:     16 years, 2009–2025, 146,984 quality-controlled records, 8 vessels
Sydney:  15 years, 2009–2024,     944 quality-controlled records, 11 vessels

------------------------------------------------------------------------------
SUMMARY STATISTICS (from cleaned data)
------------------------------------------------------------------------------

                          GBR (OTI)     Sydney (SH)     Difference
  Annual mean (°C)         24.65          21.44          +3.21
  Warmest month (Feb, °C)  27.92          23.97          +3.95
  Coolest month (Aug, °C)  21.78          18.68          +3.10
  Annual amplitude (°C)     6.14           5.28

------------------------------------------------------------------------------
NOTE ON FIGURE 1B (monthly SST anomaly panels for SGBR / SNSW regions)
------------------------------------------------------------------------------

Figure 1B is not derived from the files in this folder. Those panels were
generated by, and downloaded from, the IMOS OceanCurrent portal:

  https://oceancurrent.aodn.org.au

using its "SST Anom vs Time" product for the bounding boxes:
  SGBR: 149–157°E, 26–20°S
  SNSW: 150–156°E, 37–32°S

The anomalies are computed by IMOS relative to the SST Atlas of Australian
Regional Seas (SSTAARS) climatology. To reproduce or re-download these panels,
select the corresponding region on the OceanCurrent portal and use the
"Permalink" or download options provided on that page.

------------------------------------------------------------------------------
CONTACT
------------------------------------------------------------------------------

Ayush Sharma
Laboratory of Evolutionary Protistology
Institute of Parasitology, Biology Centre CAS
České Budějovice, Czech Republic
